function find(x,n) {
    let fir = prompt("ВыБЕРИТЕ ЧИСЛО")
    let sec = prompt('Выберите степень')
    
    let res = Math.pow(fir,sec)

alert(res)
}

find()